const countries = require('./countries.json')

export default countries;