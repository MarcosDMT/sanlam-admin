export const applicationData = [
    {
        id: 1,
        refNo: 'SEP2343454',
        customerName: 'Dennis Njoroge',
        productName: 'Super Endowment Plus',
        status: 'Completed',
        stage: '-',
        regDate: '29/11/2022'
    }
];

export const customerData = [
    {
        id: 1,
        customerName: 'Dennis Njoroge',
        phoneNumber: '0712345678',
        idNumber: '23434556',
        applications: 5,
        email: 'njoro@gmail.com'
    }
]