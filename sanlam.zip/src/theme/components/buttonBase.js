
export default {
  defaultProps: {
    disableRipple: false,
  },
};
